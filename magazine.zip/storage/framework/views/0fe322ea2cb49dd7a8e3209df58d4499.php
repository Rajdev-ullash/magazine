<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h4>Create Employee</h4>
        <div class="row">
            
            <div class="col-md-6">
                <form action="<?php echo e(URL::to('/store-employee')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="mb-3 form-group">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder=""
                            value="<?php echo e(old('name')); ?>" />
                        <?php if($errors->has('name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" name="email" id="email" class="form-control" placeholder=""
                            value="<?php echo e(old('email')); ?>" />
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="department" class="form-label">Select Department</label>
                        <select class="form-select form-select-lg" name="department" id="department">
                            <option value="" <?php echo e(old('department') == '' ? 'selected' : ''); ?>>Select Department
                            </option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>" <?php echo e(old('department') == $d->id ? 'selected' : ''); ?>>
                                    <?php echo e($d->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('department')): ?>
                            <span class="text-danger"><?php echo e($errors->first('department')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="birth_date" class="form-label">Birth Date</label>
                        <input type="date" name="birth_date" id="birth_date" class="form-control" placeholder="" />
                        <?php if($errors->has('birth_date')): ?>
                            <span class="text-danger"><?php echo e($errors->first('birth_date')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="salary" class="form-label">Salary</label>
                        <input type="number" name="salary" id="salary" class="form-control" placeholder=""
                            value="<?php echo e(old('salary')); ?>" />
                        <?php if($errors->has('salary')): ?>
                            <span class="text-danger"><?php echo e($errors->first('salary')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="gender" class="form-label">Choose gender</label>
                        <br />
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="gender_male"
                                value="male" <?php echo e(old('gender') == 'male' ? 'checked' : ''); ?> />
                            <label class="form-check-label" for="gender_male">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="gender_female"
                                value="female" <?php echo e(old('gender') == 'female' ? 'checked' : ''); ?> />
                            <label class="form-check-label" for="gender_female">Female</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="gender_other"
                                value="other" <?php echo e(old('gender') == 'other' ? 'checked' : ''); ?> />
                            <label class="form-check-label" for="gender_other">Other</label>
                        </div>
                        <?php if($errors->has('gender')): ?>
                            <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" name="address" id="" rows="3"><?php echo e(old('address')); ?></textarea>
                        <?php if($errors->has('address')): ?>
                            <div class="text-danger"><?php echo e($errors->first('address')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            Add
                        </button>
                        <a href="<?php echo e(URL::to('/all-employee')); ?>" class="btn btn-primary">Employee List</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/employee/create.blade.php ENDPATH**/ ?>