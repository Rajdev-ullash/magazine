<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h4>Edit Employee</h4>
        <div class="row">
            <div class="col-md-6">
                <?php if(Session::has('msg')): ?>
                    <div class="alert alert-success">
                        <strong><?php echo e(Session::get('msg')); ?></strong>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(URL::to('/update-employee/' . $data->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="mb-3 form-group">
                        <label for="name" class="form-label">Name</label>
                        <input value=<?php echo e($data->name); ?> type="text" name="name" id="name"
                            class="form-control" placeholder="" />
                    </div>
                    <div class="mb-3 form-group">
                        <label for="email" class="form-label">Email</label>
                        <input value=<?php echo e($data->email); ?> type="text" name="email" id="email"
                            class="form-control" placeholder="" />
                    </div>
                    <div class="mb-3 form-group">
                        <label for="birth_date" class="form-label">Birth Date</label>
                        <input value=<?php echo e($data->birth_date); ?> type="date" name="birth_date" id="birth_date"
                            class="form-control" placeholder="" />
                    </div>
                    <div class="mb-3 form-group">
                        <label for="salary" class="form-label">Salary</label>
                        <input value=<?php echo e($data->salary); ?> type="number" name="salary" id="salary"
                            class="form-control" placeholder="" />
                    </div>
                    <div class="mb-3 form-group">
                        <label for="gender" class="form-label">Choose gender</label>
                        <br />
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="" value="male"
                                <?php echo e($data->gender == 'male' ? 'checked' : ''); ?> />
                            <label class="form-check-label" for="">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="" value="female"
                                <?php echo e($data->gender == 'female' ? 'checked' : ''); ?> />
                            <label class="form-check-label" for="">Female</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="" value="other"
                                <?php echo e($data->gender == 'other' ? 'checked' : ''); ?> />
                            <label class="form-check-label" for="">Other</label>
                        </div>
                    </div>
                    <div class="mb-3 form-group">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" name="address" id="" rows="3"><?php echo e($data->address); ?></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            Update
                        </button>
                        <a href="<?php echo e(URL::to('/all-employee')); ?>" class="btn btn-primary">Employee List</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/employee/edit.blade.php ENDPATH**/ ?>