
<?php $__env->startSection('single'); ?>
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
            <div class="col-lg-6">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                        <?php if(Session::has('err_msg')): ?>
                            <div class="alert alert-danger mt-5">
                                <strong><?php echo e(Session::get('err_msg')); ?></strong>
                            </div>
                        <?php endif; ?>
                    </div>
                    <form class="user" action="<?php echo e(URL::to('login-store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input value="<?php echo e(old('email')); ?>" type="email" class="form-control form-control-user"
                                id="exampleInputEmail" name="email" aria-describedby="emailHelp"
                                placeholder="Enter Email Address...">
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <input value="<?php echo e(old('password')); ?>" type="password" class="form-control form-control-user"
                                name="password" id="exampleInputPassword" placeholder="Password">
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>

                        <input type="submit" name="submit" class="btn btn-primary btn-user btn-block" value="Login">


                        <hr>

                    </form>
                    <hr>
                    <div class="text-center">
                        <a class="small" href="forgot-password.html">Forgot Password?</a>
                    </div>
                    <div class="text-center">
                        <a class="small" href="<?php echo e(URL::to('register')); ?>">Create an Account!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\munna vai\magazine\resources\views/admin/pages/login.blade.php ENDPATH**/ ?>