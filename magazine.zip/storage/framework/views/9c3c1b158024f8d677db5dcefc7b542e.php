<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>

<body>
    <div id="login">
        <h3 class="text-center text-white pt-5">Admin Login</h3>
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="<?php echo e(URL::to('login-store')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <h3 class="text-center text-info">Login</h3>
                            <?php if(Session::has('err_msg')): ?>
                                <div class="alert alert-danger mt-5">
                                    <strong><?php echo e(Session::get('err_msg')); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label for="email" class="text-info">Email:</label><br>
                                <input value="<?php echo e(old('email')); ?>" type="email" name="email" id="email"
                                    class="form-control">
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Password:</label><br>
                                <input type="text" name="password" id="password" class="form-control"
                                    value="<?php echo e(old('password')); ?>">
                                <?php if($errors->has('password')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/login.blade.php ENDPATH**/ ?>