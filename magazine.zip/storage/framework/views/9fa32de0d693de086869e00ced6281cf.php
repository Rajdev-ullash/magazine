<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <h1>Product List</h1>

    <div class="container">
        <table class="table table-primary">
            <thead>
                <tr>
                    <th class="col">Id</th>
                    <th class="col">Name</th>
                    <th class="col">Price</th>
                </tr>
            </thead>
            <tbody>
                <?php if($products): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($p['id']); ?></th>
                            <td><?php echo e($p['name']); ?></td>
                            <td><?php echo e($p['price']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-center">No Data Found</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/products.blade.php ENDPATH**/ ?>