<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>News</title>
</head>

<body>
    <h2>News page</h2>
    <h2>Category: <?php echo e($cat); ?></h2>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/others/news.blade.php ENDPATH**/ ?>