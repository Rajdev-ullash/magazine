
<?php $__env->startSection('single'); ?>
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
            <div class="col-lg-7">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                    </div>
                    <form class="user" action="<?php echo e(URL::to('store-user')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" id="name" name="name"
                                value="<?php echo e(old('name')); ?>" placeholder="Enter your name">
                            <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <select class="form-control form-select" name="type" id="type">
                                <option value="" <?php echo e(old('type') === null || old('type') == '' ? 'selected' : ''); ?>>
                                    Select User Type</option>
                                <option value="admin" <?php echo e(old('type') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                <option value="editor" <?php echo e(old('type') == 'editor' ? 'selected' : ''); ?>>Editor</option>
                            </select>
                            <?php if($errors->has('type')): ?>
                                <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <input type="email" name="email" class="form-control form-control-user" id="email"
                                placeholder="Email Address" value="<?php echo e(old('email')); ?>">
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-user" id="password" name="password"
                                value="<?php echo e(old('password')); ?>" placeholder="Password">
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                        <input name="submit" type="submit" value="Register" class="btn btn-primary btn-user btn-block">

                        <hr>
                    </form>
                    <hr>
                    
                    <div class="text-center">
                        <a class="small" href="<?php echo e(URL::to('login')); ?>">Already have an account? Login!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\munna vai\magazine\resources\views/admin/pages/register.blade.php ENDPATH**/ ?>