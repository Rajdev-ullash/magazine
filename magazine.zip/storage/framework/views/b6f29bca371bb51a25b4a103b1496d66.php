
<?php $__env->startSection('links'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            
            <div class="offset-2 col-lg-8">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-2">Create Article</h1>
                    </div>
                    <form class="user" action="<?php echo e(URL::to('store-article')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <input type="text" class="form-control" id="title" name="title"
                                value="<?php echo e(old('title')); ?>" placeholder="Enter your article name">
                            <?php if($errors->has('title')): ?>
                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <select class="form-select form-select-lg form-control" name="category" id="category">
                                <option value="" <?php echo e(old('category') == '' ? 'selected' : ''); ?>>Select category
                                </option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>" <?php echo e(old('category') == $d->id ? 'selected' : ''); ?>>
                                        <?php echo e($d->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('category')): ?>
                                <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" id="short_des" name="short_des" rows="3"
                                placeholder="Enter your article short description"><?php echo e(old('short_des')); ?></textarea>
                            <?php if($errors->has('short_des')): ?>
                                <span class="text-danger"><?php echo e($errors->first('short_des')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" id="details" name="details" placeholder="Enter your article description"
                                value="<?php echo e(old('details')); ?>"><?php echo e(old('details')); ?></textarea>
                            <?php if($errors->has('details')): ?>
                                <span class="text-danger"><?php echo e($errors->first('details')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="main_image">Select your main image</label>
                            <input type="file" class="form-control" id="main_image" name="main_image">
                            <?php if($errors->has('main_image')): ?>
                                <span class="text-danger"><?php echo e($errors->first('main_image')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="thumbnail_image">Select your thumbnail image</label>
                            <input type="file" class="form-control" id="thumbnail_image" name="thumbnail_image">
                            <?php if($errors->has('thumbnail_image')): ?>
                                <span class="text-danger"><?php echo e($errors->first('thumbnail_image')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div id="images">
                            <?php if(old('images')): ?>
                                <?php $__currentLoopData = old('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group image-upload">
                                        <label for="images[]">Images</label>
                                        <input type="file"
                                            class="form-control <?php $__errorArgs = ['images.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="images[]">
                                        <?php $__errorArgs = ['images.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="captions[]">Captions</label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['captions.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="captions[]" value="<?php echo e(old('captions.' . $index)); ?>"
                                            placeholder="Caption for image">
                                        <?php $__errorArgs = ['captions.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="form-group image-upload">
                                    <label for="images[]">Images</label>
                                    <input type="file" class="form-control" name="images[]">
                                    <label for="captions[]">Captions</label>
                                    <input type="text" class="form-control" name="captions[]"
                                        placeholder="Caption for image">
                                    
                                </div>
                            <?php endif; ?>
                        </div>

                        <button class="btn btn-primary mb-2" type="button" id="add_image">Add another image</button>

                        <div class="form-group">
                            <input type="text" class="form-control" id="writer" name="writer"
                                value="<?php echo e(old('writer')); ?>" placeholder="Enter your writer name">
                            <?php if($errors->has('writer')): ?>
                                <span class="text-danger"><?php echo e($errors->first('writer')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <select class="form-select form-select-lg form-control" name="show_home_page"
                                id="show_home_page">
                                <option value="" <?php echo e(old('show_home_page') == '' ? 'selected' : ''); ?>>Select show home
                                    page</option>
                                <option value="1" <?php echo e(old('show_home_page') == '1' ? 'selected' : ''); ?>>Yes</option>
                                <option value="0" <?php echo e(old('show_home_page') == '0' ? 'selected' : ''); ?>>No</option>
                            </select>
                            <?php if($errors->has('show_home_page')): ?>
                                <span class="text-danger"><?php echo e($errors->first('show_home_page')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <select class="form-select form-select-lg form-control" name="features" id="features">
                                <option value="" <?php echo e(old('features') == '' ? 'selected' : ''); ?>>Is features!</option>
                                <option value="1" <?php echo e(old('features') == '1' ? 'selected' : ''); ?>>Yes</option>
                                <option value="0" <?php echo e(old('features') == '0' ? 'selected' : ''); ?>>No</option>
                            </select>
                            <?php if($errors->has('features')): ?>
                                <span class="text-danger"><?php echo e($errors->first('features')); ?></span>
                            <?php endif; ?>
                        </div>

                        <input name="submit" type="submit" value="Create" class="btn btn-primary btn-user btn-block">
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        ClassicEditor
            .create(document.querySelector('#details'))
            .then(editor => {
                editor.editing.view.change(writer => {
                    writer.setStyle('min-height', '200px', editor.editing.view.document.getRoot());
                });
            })
            .catch(error => {
                console.error(error);
            });

        document.getElementById('add_image').addEventListener('click', function() {
            let imageUploadDiv = document.createElement('div');
            imageUploadDiv.className = 'form-group image-upload';

            imageUploadDiv.innerHTML = `
                <label for="images[]">Images</label>
                <input type="file" class="form-control" name="images[]">
                <label for="captions[]">Captions</label>
                <input type="text" class="form-control" name="captions[]" placeholder="Caption for image">
                <button type="button" class="btn btn-danger remove-image">Remove</button>
            `;

            document.getElementById('images').appendChild(imageUploadDiv);
        });

        document.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('remove-image')) {
                e.target.parentElement.remove();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\munna vai\magazine\resources\views/admin/pages/article/create.blade.php ENDPATH**/ ?>