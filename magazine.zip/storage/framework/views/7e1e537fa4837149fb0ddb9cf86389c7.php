

<?php $__env->startSection('content'); ?>
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            
            <div class="offset-3 col-lg-6">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Create Category</h1>
                    </div>
                    <form class="user" action="<?php echo e(URL::to('store-category')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" id="name" name="name"
                                value="<?php echo e(old('name')); ?>" placeholder="Enter your category name">
                            <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <input name="submit" type="submit" value="Create" class="btn btn-primary btn-user btn-block">


                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\munna vai\magazine\resources\views/admin/pages/category/create.blade.php ENDPATH**/ ?>