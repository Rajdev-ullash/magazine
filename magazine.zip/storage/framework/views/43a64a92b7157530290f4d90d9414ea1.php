<!DOCTYPE html>
<html lang="en">

<head>

    <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <?php echo $__env->yieldContent('single'); ?>
        </div>

    </div>

    <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/admin/layouts/single.blade.php ENDPATH**/ ?>