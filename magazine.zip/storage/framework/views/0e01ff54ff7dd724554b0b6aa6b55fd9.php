<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Employees</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="container">
        <?php if(Session::has('msg')): ?>
            <div class="alert alert-danger mt-5">
                <strong><?php echo e(Session::get('msg')); ?></strong>
            </div>
        <?php endif; ?>
        <h4>All Employees</h4>
        <a href="<?php echo e(URL::to('/create-employee')); ?>" class="btn btn-primary">Create Employee</a>
        <table class="table table-primary">
            <thead>
                <tr>
                    <th class="col">Id</th>
                    <th class="col">Name</th>
                    <th class="col">Email</th>
                    <th class="col">Department</th>
                    <th class="col">Address</th>
                    <th class="col">Birth Date</th>
                    <th class="col">Salary</th>
                    <th class="col">Gender</th>
                    <th class="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($data): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($c->id); ?></td>
                            <td><?php echo e($c->name); ?></td>
                            <td><?php echo e($c->email); ?></td>
                            <td><?php echo e($c->dept_name); ?></td>
                            <td><?php echo e($c->address); ?></td>
                            <td><?php echo e($c->birth_date); ?></td>
                            <td><?php echo e($c->salary); ?></td>
                            <td><?php echo e($c->gender); ?></td>
                            <td>
                                <a href="<?php echo e(URL::to('/edit-employee/' . $c->id)); ?>"
                                    class="btn btn-warning btn-sm">Edit</a>
                                <a data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($c->id); ?>"
                                    href="" class="btn btn-danger btn-sm">Delete</a>
                                <div class="modal fade" id="exampleModal<?php echo e($c->id); ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Confirmation
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Are you sure you want to delete <b><?php echo e($c->name); ?></b>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <a href="<?php echo e(URL::to('/delete-employee/' . $c->id)); ?>"
                                                    class="btn btn-danger">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-center">No Data Found</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/employee/all.blade.php ENDPATH**/ ?>