<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Course</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h4>Create Course</h4>
        <div class="row">
            <div class="col-md-6">
                <?php if(Session::has('msg')): ?>
                    <div class="alert alert-success">
                        <strong><?php echo e(Session::get('msg')); ?></strong>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(URL::to('/update-course/' . $course->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="mb-3 form-group">
                        <label for="course_name" class="form-label">Course Name</label>
                        <input value="<?php echo e($course->course_name); ?>" type="text" name="course_name" id="course_name"
                            class="form-control" placeholder="" />
                    </div>
                    <div class="mb-3 form-group">
                        <label for="course_code" class="form-label">Course Code</label>
                        <input value="<?php echo e($course->course_code); ?>" type="text" name="course_code" id="course_code"
                            class="form-control" placeholder="" />
                    </div>
                    <div class="mb-3 form-group">
                        <label for="course_type" class="form-label">Course Type</label>
                        <select class="form-select form-select-lg" name="course_type" id="">
                            <option>Select Type</option>
                            <option value="theory" <?php echo e($course->course_type == 'theory' ? 'selected' : ''); ?>>Theory
                            </option>
                            <option value="lab" <?php echo e($course->course_type == 'lab' ? 'selected' : ''); ?>>Lab</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            Update
                        </button>
                        <a href="<?php echo e(URL::to('/all-course')); ?>" class="btn btn-primary">All Course</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\munna vai\magazine\resources\views/course/edit.blade.php ENDPATH**/ ?>