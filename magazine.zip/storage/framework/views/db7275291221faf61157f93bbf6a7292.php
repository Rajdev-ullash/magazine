
<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('admin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Tables</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Category List</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Tile</th>
                                <th>Category</th>
                                <th>Short Description</th>
                                
                                <th>Main Image</th>
                                <th>Thumbnail Image</th>
                                <th>Writer</th>
                                <th>Publish Date</th>
                                <th>Status</th>
                                <th>Show home page</th>
                                <th>Feature</th>
                                <th>Other Images</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        
                        <tbody>

                            <?php if($articles): ?>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"><?php echo e($c->id); ?></td>
                                        <td><?php echo e($c->title); ?></td>
                                        <td><?php echo e($c->category->name); ?></td>
                                        <td><?php echo e($c->short_description); ?></td>
                                        
                                        <td>
                                            <img src="<?php echo e(asset($c->main_image)); ?>" alt="main" width="100px" />
                                        </td>
                                        <td>
                                            <img src="<?php echo e(asset($c->thumbnail_image)); ?>" alt="main" width="100px" />
                                        </td>
                                        <td><?php echo e($c->writer); ?></td>
                                        <td><?php echo e($c->publish_date); ?></td>
                                        <td><?php echo e($c->status ? 'Active' : 'Inactive'); ?></td>
                                        <td><?php echo e($c->show_home_page ? 'Yes' : 'No'); ?></td>
                                        <td><?php echo e($c->features ? 'Yes' : 'No'); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $c->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-2">
                                                    <img src="<?php echo e(asset($image->image_path)); ?>" alt="image"
                                                        width="100px" />
                                                    <p><b><?php echo e($image->caption); ?></b></p>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(URL::to('/edit-article/' . $c->id)); ?>"
                                                class="btn btn-warning btn-sm">Edit</a>
                                            <a data-toggle="modal" data-target="#exampleModal<?php echo e($c->id); ?>"
                                                href="" class="btn btn-danger btn-sm">Delete</a>
                                            <div class="modal fade" id="exampleModal<?php echo e($c->id); ?>" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Delete
                                                                Confirmation
                                                            </h1>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Are you sure you want to delete <b><?php echo e($c->name); ?></b>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Close</button>
                                                            <a href="<?php echo e(URL::to('/delete-category/' . $c->id)); ?>"
                                                                class="btn btn-danger">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="text-center">No Data Found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('admin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('admin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\munna vai\magazine\resources\views/admin/pages/article/all.blade.php ENDPATH**/ ?>