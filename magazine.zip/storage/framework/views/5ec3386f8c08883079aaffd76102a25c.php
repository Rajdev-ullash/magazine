

<?php $__env->startSection('slider'); ?>
    <?php if($articles_show_home_page->count()): ?>
        <?php
            $displayed_articles = [];
        ?>
        <?php $__currentLoopData = $articles_show_home_page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!in_array($article->id, $displayed_articles)): ?>
                <?php
                    $displayed_articles[] = $article->id;
                ?>
                <div class="swiper-slide">
                    <div class="flex flex-col md:grid md:grid-cols-2 md:col-spans-2 lg:grid-cols-4 gap-[30px]">
                        <div class="md:col-span-2">
                            <div
                                class="grid md:grid-cols-2 justify-start items-center gap-4 rounded-3xl overflow-hidden border-2 bg-neutral-950 border-neutral-700 dark:border-neutral-dark-300 hover-up">
                                <a class='rounded-2xl overflow-hidden' href='<?php echo e(URL::to('article/' . $article->slug)); ?>'>
                                    <img class="md:min-h-[340px] w-auto" src="<?php echo e(asset($article->thumbnail_image)); ?>" />
                                </a>
                                <div class="flex flex-col justify-start items-start gap-4 p-8">
                                    <div class="justify-start items-center gap-5 flex">
                                        <a class='px-3 py-[8px] bg-neutral-200 dark:bg-neutral-dark-200 rounded-3xl border border-neutral-200 dark:border-neutral-dark-300 justify-center items-center gap-2.5 flex'
                                            href='<?php echo e(URL::to('category/' . $article->category->id)); ?>'>
                                            <div
                                                class="text-neutral-900 dark:text-neutral-dark-950 text-sm font-medium leading-none">
                                                <?php echo e($article->category->name); ?></div>
                                        </a>
                                        <div class="justify-start items-center gap-2 flex">
                                            <a href="author.html" class="w-9 h-9"><img class="w-9 h-9 rounded-3xl"
                                                    src="<?php echo e(asset('user/imgs/avatar/avatar-01.png')); ?>" /></a>
                                            <div
                                                class="text-neutral-700 text-sm font-medium leading-none dark:text-neutral-dark-300">
                                                <a href="author.html"><?php echo e($article->writer); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <h4>
                                        <a class='text-neutral-0 dark:text-neutral-dark-950 text-lg font-bold item-link'
                                            href='<?php echo e(URL::to('article/' . $article->slug)); ?>'><?php echo e($article->title); ?></a>
                                    </h4>
                                    <p class="text-neutral-700 text-sm font-medium leading-snug dark:text-neutral-dark-300">
                                        <?php echo e($article->short_description); ?>

                                    </p>
                                </div>
                            </div>
                        </div>

                        <?php
                            $extra_count = 0;
                        ?>
                        <?php $__currentLoopData = $articles_show_home_page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra_index => $extra_article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($extra_article->id != $article->id && !in_array($extra_article->id, $displayed_articles) && $extra_count < 2): ?>
                                <?php
                                    $displayed_articles[] = $extra_article->id;
                                    $extra_count++;
                                ?>
                                <div
                                    class="rounded-3xl bg-neutral-950 border-2 border-neutral-dark-300 dark:border-neutral-dark-300 flex-col justify-start items-start inline-flex overflow-hidden hover-up">
                                    <div class="justify-start items-center gap-4 flex flex-col">
                                        <a class='rounded-[18px] overflow-hidden max-h-[180px]'
                                            href='<?php echo e(URL::to('article/' . $extra_article->slug)); ?>'>
                                            <img src="<?php echo e(asset($extra_article->thumbnail_image)); ?>" />
                                        </a>
                                        <div class="p-4 flex-col gap-4 inline-flex items-center md:items-start">
                                            <div class="justify-start items-center gap-2 inline-flex">
                                                <a class='px-3 py-[8px] bg-neutral-200 dark:bg-neutral-dark-200 rounded-3xl border border-neutral-200 dark:border-neutral-dark-300 justify-center items-center gap-2.5 flex'
                                                    href='<?php echo e(URL::to('category/' . $extra_article->category->id)); ?>'>
                                                    <div
                                                        class="text-neutral-900 dark:text-neutral-dark-950 text-sm font-medium leading-none">
                                                        <?php echo e($extra_article->category->name); ?></div>
                                                </a>
                                                <div class="justify-start items-center gap-2 flex">
                                                    <div
                                                        class="text-neutral-700 text-sm font-regular leading-none dark:text-neutral-dark-700">
                                                        <?php echo e($extra_article->publish_date); ?></div>
                                                </div>
                                            </div>
                                            <h3 class="text-center md:text-start mb-4 md-mb-0">
                                                <a class='text-neutral-dark-950 dark:text-neutral-dark-950 text-lg font-bold leading-tight item-link'
                                                    href='<?php echo e(URL::to('article/' . $extra_article->slug)); ?>'><?php echo e($extra_article->title); ?></a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($extra_count < 2): ?>
                            <?php $__currentLoopData = $articles_show_home_page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra_article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!in_array($extra_article->id, $displayed_articles) && $extra_count < 2): ?>
                                    <?php
                                        $displayed_articles[] = $extra_article->id;
                                        $extra_count++;
                                    ?>
                                    <div
                                        class="rounded-3xl bg-neutral-950 border-2 border-neutral-dark-300 dark:border-neutral-dark-300 flex-col justify-start items-start inline-flex overflow-hidden hover-up">
                                        <div class="justify-start items-center gap-4 flex flex-col">
                                            <a class='rounded-[18px] overflow-hidden max-h-[180px]'
                                                href='<?php echo e(URL::to('article/' . $extra_article->slug)); ?>'>
                                                <img src="<?php echo e(asset($extra_article->thumbnail_image)); ?>" />
                                            </a>
                                            <div class="p-4 flex-col gap-4 inline-flex items-center md:items-start">
                                                <div class="justify-start items-center gap-2 inline-flex">
                                                    <a class='px-3 py-[8px] bg-neutral-200 dark:bg-neutral-dark-200 rounded-3xl border border-neutral-200 dark:border-neutral-dark-300 justify-center items-center gap-2.5 flex'
                                                        href='<?php echo e(URL::to('category/' . $extra_article->category->id)); ?>'>
                                                        <div
                                                            class="text-neutral-900 dark:text-neutral-dark-950 text-sm font-medium leading-none">
                                                            <?php echo e($extra_article->category->name); ?></div>
                                                    </a>
                                                    <div class="justify-start items-center gap-2 flex">
                                                        <div
                                                            class="text-neutral-700 text-sm font-regular leading-none dark:text-neutral-dark-700">
                                                            <?php echo e($extra_article->publish_date); ?></div>
                                                    </div>
                                                </div>
                                                <h3 class="text-center md:text-start mb-4 md-mb-0">
                                                    <a class='text-neutral-dark-950 dark:text-neutral-dark-950 text-lg font-bold leading-tight item-link'
                                                        href='<?php echo e(URL::to('article/' . $extra_article->slug)); ?>'><?php echo e($extra_article->title); ?></a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\munna vai\magazine\resources\views/user/pages/index.blade.php ENDPATH**/ ?>