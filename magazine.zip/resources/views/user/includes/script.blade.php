<script src="{{ asset('user/js/vendors/jquery-3.7.1.min.js') }}"></script>
<script src="{{ asset('user/js/vendors/jquery-migrate-3.3.0.min.js') }}"></script>
<script src="{{ asset('user/js/vendors/modernizr-3.6.0.min.js') }}"></script>
<script src="{{ asset('user/js/vendors/jquery.scrollUp.min.js') }}"></script>
<script src="{{ asset('user/js/vendors/swiper-bundle.js') }}"></script>
<script src="{{ asset('user/js/vendors/waypoints.min.js') }}"></script>
<script src="{{ asset('user/js/vendors/wow.min.js') }}"></script>
<script src="{{ asset('user/js/vendors/lightbox.js') }}"></script>
<script src="{{ asset('user/js/vendors/alpine.min.js') }}"></script>

<script src="{{ asset('user/js/main.js') }}"></script>
